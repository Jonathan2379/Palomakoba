package com.unir.appcomprasv2;

import com.unir.appcomprasv2.util.DSL;
import com.unir.appcomprasv2.util.DriverFactory;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class SimulaCompraIDSL {

    private AndroidDriver<MobileElement> driver;
    private final DSL dsl = new DSL();

    @Before
    public void setUp(){
        driver = DriverFactory.getDriver();
    }

    @Test
    public void sampleTest() throws InterruptedException{
        dsl.clicar(By.id("com.unir.appcomprasv2:id/salada"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/bisteca"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/pure"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/macarrao"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/feijao"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/arroz"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/btn_total"));
        dsl.clicar(By.id("com.unir.appcomprasv2:id/rb_quinze"));

        dsl.escrever(By.id("com.unir.appcomprasv2:id/pagamento"),"21.15");

        DriverFactory.threadOneSecond();

        dsl.clicar(By.id("com.unir.appcomprasv2:id/btn_pagamento"));

        DriverFactory.threadTwoSecond();
        Assert.assertEquals("Compra realizada com sucesso!", dsl.obterTexto(By.id("com.unir.appcomprasv2:id/alertTitle")));

    }

    @After
    public void tearDown() throws InterruptedException{
        DriverFactory.threadTwoSecond();
        DriverFactory.finalizarDriver();
    }
}