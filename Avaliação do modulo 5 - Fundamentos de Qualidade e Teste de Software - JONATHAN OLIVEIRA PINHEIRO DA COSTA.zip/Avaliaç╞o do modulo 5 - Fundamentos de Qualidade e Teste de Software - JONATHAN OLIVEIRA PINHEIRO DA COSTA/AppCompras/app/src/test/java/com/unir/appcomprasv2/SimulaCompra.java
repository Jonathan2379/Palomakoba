package com.unir.appcomprasv2;

import android.widget.Toast;

import com.unir.appcomprasv2.util.DriverFactory;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.net.MalformedURLException;

public class SimulaCompra {

    private AndroidDriver driver;

    @Before
    public void setUp() throws MalformedURLException {
        driver = DriverFactory.getDriver();
    }

    @Test
    public void sampleTest() throws InterruptedException  {
        MobileElement el2 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/arroz");
        el2.click();
        MobileElement el3 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/feijao");
        el3.click();
        MobileElement el4 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/macarrao");
        el4.click();
        MobileElement el5 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/pure");
        el5.click();
        MobileElement el6 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/bisteca");
        el6.click();
        MobileElement el7 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/salada");
        el7.click();
        MobileElement el8 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/btn_total");
        el8.click();
        MobileElement el9 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/rb_quinze");
        el9.click();
        MobileElement el10 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/pagamento");
        el10.click();
        el10.sendKeys("50");
        MobileElement el11 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/btn_pagamento");
        el11.click();

        DriverFactory.threadTwoSecond();
        MobileElement el12 = (MobileElement) driver.findElementById("com.unir.appcomprasv2:id/alertTitle");
        el12.click();

        DriverFactory.threadTwoSecond();
        Assert.assertEquals("Compra realizada com sucesso!", el12.getText());

        DriverFactory.threadTwoSecond();
        MobileElement el13 = (MobileElement) driver.findElementById("android:id/button1");
        el13.click();

    }

    @After
    public void tearDown() throws InterruptedException  {
        DriverFactory.threadTwoSecond();
        driver.quit();
    }
}
